package com.cerma.balicek;

public class Pes {
    public void stekat(){
        System.out.println("Pes steka z balicku");

    }
}
