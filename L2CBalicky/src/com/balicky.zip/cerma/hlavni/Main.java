package com.cerma.hlavni;

public class Main {

    public static void main(String[] args) {
    com.cerma.balicek.Pes punta = new com.cerma.balicek.Pes();
    com.cerma.balik.Pes azor = new com.cerma.balik.Pes();

    azor.stekat();
    punta.stekat();
    }
}
