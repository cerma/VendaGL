package com.cerma.balik;

public class Pes {
    public void stekat(){
        System.out.println("Pes steka z baliku");

    }

}
