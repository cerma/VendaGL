package com.cerma;

public class VitrException extends Exception{
    public VitrException(String hlaska){
        super(hlaska);
    }
}
