package com.cerma;

public class PocasiException extends RuntimeException{
    public PocasiException(String hlaska){
        super(hlaska);
    }
}
